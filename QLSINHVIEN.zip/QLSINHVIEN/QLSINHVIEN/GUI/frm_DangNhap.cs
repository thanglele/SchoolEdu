﻿using System;

namespace QLSINHVIEN
{
    internal class frm_DangNhap
    {
        public frm_DangNhap()
        {
        }

        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}