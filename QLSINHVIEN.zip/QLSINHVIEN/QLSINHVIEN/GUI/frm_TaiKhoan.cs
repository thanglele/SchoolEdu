﻿using System.Windows.Forms;

namespace QLSINHVIEN
{
    internal class frm_TaiKhoan : Form
    {
    }
}