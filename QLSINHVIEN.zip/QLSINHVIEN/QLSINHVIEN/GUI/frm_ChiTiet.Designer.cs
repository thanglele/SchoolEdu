﻿
namespace QLSINHVIEN.GUI
{
    partial class frm_ChiTiet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lb_MaSV = new System.Windows.Forms.Label();
            this.lb_TenSV = new System.Windows.Forms.Label();
            this.lb_NgaySinh = new System.Windows.Forms.Label();
            this.lb_MaLop = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_Dong = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lb_MaSV);
            this.groupBox1.Controls.Add(this.lb_TenSV);
            this.groupBox1.Controls.Add(this.lb_NgaySinh);
            this.groupBox1.Controls.Add(this.lb_MaLop);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold);
            this.groupBox1.Location = new System.Drawing.Point(35, 52);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(507, 341);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông Tin Sinh Viên";
            // 
            // lb_MaSV
            // 
            this.lb_MaSV.AutoSize = true;
            this.lb_MaSV.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold);
            this.lb_MaSV.ForeColor = System.Drawing.Color.Red;
            this.lb_MaSV.Location = new System.Drawing.Point(199, 66);
            this.lb_MaSV.Name = "lb_MaSV";
            this.lb_MaSV.Size = new System.Drawing.Size(77, 26);
            this.lb_MaSV.TabIndex = 9;
            this.lb_MaSV.Text = "MaSV";
            // 
            // lb_TenSV
            // 
            this.lb_TenSV.AutoSize = true;
            this.lb_TenSV.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold);
            this.lb_TenSV.ForeColor = System.Drawing.Color.Red;
            this.lb_TenSV.Location = new System.Drawing.Point(199, 118);
            this.lb_TenSV.Name = "lb_TenSV";
            this.lb_TenSV.Size = new System.Drawing.Size(79, 26);
            this.lb_TenSV.TabIndex = 8;
            this.lb_TenSV.Text = "TenSV";
            // 
            // lb_NgaySinh
            // 
            this.lb_NgaySinh.AutoSize = true;
            this.lb_NgaySinh.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold);
            this.lb_NgaySinh.ForeColor = System.Drawing.Color.Red;
            this.lb_NgaySinh.Location = new System.Drawing.Point(199, 170);
            this.lb_NgaySinh.Name = "lb_NgaySinh";
            this.lb_NgaySinh.Size = new System.Drawing.Size(111, 26);
            this.lb_NgaySinh.TabIndex = 7;
            this.lb_NgaySinh.Text = "NgaySinh";
            // 
            // lb_MaLop
            // 
            this.lb_MaLop.AutoSize = true;
            this.lb_MaLop.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold);
            this.lb_MaLop.ForeColor = System.Drawing.Color.Red;
            this.lb_MaLop.Location = new System.Drawing.Point(199, 274);
            this.lb_MaLop.Name = "lb_MaLop";
            this.lb_MaLop.Size = new System.Drawing.Size(88, 26);
            this.lb_MaLop.TabIndex = 6;
            this.lb_MaLop.Text = "MaLop";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(42, 116);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(170, 26);
            this.label6.TabIndex = 4;
            this.label6.Text = "Tên Sinh Viên :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(42, 168);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 26);
            this.label5.TabIndex = 3;
            this.label5.Text = "Ngày Sinh :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 272);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 26);
            this.label3.TabIndex = 1;
            this.label3.Text = "Mã Lớp :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(166, 26);
            this.label2.TabIndex = 0;
            this.label2.Text = "Mã Sinh Viên :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(153, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(247, 35);
            this.label1.TabIndex = 1;
            this.label1.Text = "Chi Tiết Sinh Viên";
            // 
            // bt_Dong
            // 
            this.bt_Dong.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.bt_Dong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_Dong.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold);
            this.bt_Dong.Location = new System.Drawing.Point(364, 398);
            this.bt_Dong.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bt_Dong.Name = "bt_Dong";
            this.bt_Dong.Size = new System.Drawing.Size(122, 35);
            this.bt_Dong.TabIndex = 2;
            this.bt_Dong.Text = "Đóng";
            this.bt_Dong.UseVisualStyleBackColor = false;
            this.bt_Dong.Click += new System.EventHandler(this.bt_Dong_Click);
            // 
            // frm_ChiTiet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PapayaWhip;
            this.ClientSize = new System.Drawing.Size(582, 442);
            this.ControlBox = false;
            this.Controls.Add(this.bt_Dong);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frm_ChiTiet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.frm_ChiTiet_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_MaSV;
        private System.Windows.Forms.Label lb_TenSV;
        private System.Windows.Forms.Label lb_NgaySinh;
        private System.Windows.Forms.Label lb_MaLop;
        private System.Windows.Forms.Button bt_Dong;
    }
}